import customtkinter as ctk
import ollama
import threading
import fitz
import os
from tkinter import filedialog
import pystray
from PIL import Image
import sys

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

conversation_history = []

SIDEBAR_WIDTH = 360
TAB_WIDTH = 44
TAB_HEIGHT = 120
MINI_SIZE = 60
ANIMATION_STEPS = 14
ANIMATION_DELAY = 10
MODEL = "phi4-mini"

THEMES = {
    "Purple": {
        "accent": "#a78bfa", "button": "#4c1d95", "button_hover": "#6d28d9",
        "bg": "#0d0d1a", "header": "#13132b", "input": "#1a1a35",
        "border": "#2e2e5e", "text": "#dddddd", "appearance": "dark"
    },
    "Dark": {
        "accent": "#e0e0e0", "button": "#333333", "button_hover": "#444444",
        "bg": "#0a0a0a", "header": "#111111", "input": "#1a1a1a",
        "border": "#2a2a2a", "text": "#dddddd", "appearance": "dark"
    },
    "Light": {
        "accent": "#6d28d9", "button": "#6d28d9", "button_hover": "#7c3aed",
        "bg": "#1e1e2e", "header": "#2a2a3e", "input": "#2e2e42",
        "border": "#4a4a6a", "text": "#e0e0e0", "appearance": "dark"
    },
}

def extract_pdf_text(path):
    doc = fitz.open(path)
    text = ""
    for page in doc:
        text += page.get_text()
    doc.close()
    return text[:8000]

def stream_text(user_input, on_chunk, on_done):
    conversation_history.append({"role": "user", "content": user_input})
    full = ""
    for chunk in ollama.chat(model=MODEL, messages=conversation_history, stream=True):
        bit = chunk["message"]["content"]
        full += bit
        on_chunk(bit)
    conversation_history.append({"role": "assistant", "content": full})
    on_done()

def stream_file(path, on_chunk, on_done):
    ext = path.lower().split(".")[-1]
    if ext == "pdf":
        text = extract_pdf_text(path)
    else:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()[:8000]
    prompt = f"Summarize this document clearly and concisely.\n\n---\n{text}"
    full = ""
    for chunk in ollama.chat(
        model=MODEL,
        messages=conversation_history + [{"role": "user", "content": prompt}],
        stream=True
    ):
        bit = chunk["message"]["content"]
        full += bit
        on_chunk(bit)
    conversation_history.append({"role": "user", "content": f"[File: {os.path.basename(path)}]"})
    conversation_history.append({"role": "assistant", "content": full})
    on_done()


class SuperpooperApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.attributes("-toolwindow", True)
        self.attributes("-alpha", 0.97)

        self.screen_w = self.winfo_screenwidth()
        self.screen_h = self.winfo_screenheight()

        self.is_open = False
        self.is_mini = False
        self.animating = False
        self.current_theme = "Purple"
        self.settings_open = False

        self.geometry(f"{TAB_WIDTH}x{self.screen_h}+0+0")
        self.configure(fg_color=self._t()["bg"])

        self._build_ui()
        self._build_tray()

    def _t(self):
        return THEMES[self.current_theme]

    def _build_ui(self):
        t = self._t()
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        # ── Tab column ────────────────────────────────────────────
        self.tab_col = ctk.CTkFrame(self, fg_color=t["bg"], corner_radius=0, width=TAB_WIDTH)
        self.tab_col.grid(row=0, column=0, sticky="ns")
        self.tab_col.grid_propagate(False)

        # Pill
        self.pill = ctk.CTkFrame(
            self.tab_col, fg_color=t["header"], corner_radius=22,
            border_width=2, border_color=t["border"],
            width=TAB_WIDTH - 10, height=TAB_HEIGHT
        )
        self.pill.place(relx=0.5, rely=0.5, anchor="center")
        self.pill.pack_propagate(False)

        self.arrow_label = ctk.CTkLabel(
            self.pill, text="›", font=("Segoe UI", 36, "bold"),
            text_color=t["accent"], fg_color="transparent",
            width=TAB_WIDTH - 10, height=TAB_HEIGHT
        )
        self.arrow_label.place(relx=0.5, rely=0.5, anchor="center")
        self.arrow_label.bind("<Button-1>", lambda e: self.toggle())
        self.pill.bind("<Button-1>", lambda e: self.toggle())

        # Separator line
        self.sep = ctk.CTkFrame(self.tab_col, fg_color=t["border"], corner_radius=0, width=1)
        self.sep.place(relx=1.0, x=-1, y=0, relheight=1.0)

        # ── Sidebar ───────────────────────────────────────────────
        self.sidebar = ctk.CTkFrame(
            self, fg_color=t["bg"],
            corner_radius=16,
            border_width=1,
            border_color=t["border"]
        )
        self.sidebar.grid(row=0, column=1, sticky="nsew", padx=(0, 8), pady=8)
        self.sidebar.grid_rowconfigure(1, weight=1)
        self.sidebar.grid_columnconfigure(0, weight=1)

        # Header
        self.header = ctk.CTkFrame(self.sidebar, fg_color=t["header"], corner_radius=12, height=58)
        self.header.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 0))
        self.header.grid_propagate(False)
        self.header.grid_columnconfigure(0, weight=1)

        self.header_label = ctk.CTkLabel(
            self.header, text="⬡  Superpooper",
            font=("Segoe UI", 14, "bold"), text_color=t["accent"]
        )
        self.header_label.grid(row=0, column=0, padx=16, pady=16, sticky="w")

        btn_frame = ctk.CTkFrame(self.header, fg_color="transparent")
        btn_frame.grid(row=0, column=1, padx=(0, 8), pady=8)

        self.settings_btn = ctk.CTkButton(
            btn_frame, text="⚙", width=32, height=28, corner_radius=6,
            font=("Segoe UI", 14), fg_color="transparent", border_width=1,
            border_color=t["border"], text_color=t["accent"], hover_color=t["input"],
            command=self.toggle_settings
        )
        self.settings_btn.grid(row=0, column=0, padx=(0, 4))

        # Minimise to square button
        self.mini_btn = ctk.CTkButton(
            btn_frame, text="⊟", width=32, height=28, corner_radius=6,
            font=("Segoe UI", 14), fg_color="transparent", border_width=1,
            border_color=t["border"], text_color=t["accent"], hover_color=t["input"],
            command=self.minimise_to_square
        )
        self.mini_btn.grid(row=0, column=1, padx=(0, 4))

        self.clear_btn = ctk.CTkButton(
            btn_frame, text="Clear", width=52, height=28, corner_radius=6,
            font=("Segoe UI", 11), fg_color="transparent", border_width=1,
            border_color=t["border"], text_color="#888", hover_color=t["input"],
            command=self.clear_chat
        )
        self.clear_btn.grid(row=0, column=2)

        # Chat box
        self.chat_box = ctk.CTkTextbox(
            self.sidebar, wrap="word", font=("Segoe UI", 12), corner_radius=8,
            fg_color=t["bg"], text_color=t["text"],
            scrollbar_button_color=t["border"], state="disabled"
        )
        self.chat_box.grid(row=1, column=0, sticky="nsew", padx=8, pady=(8, 0))

        # Settings panel
        self.settings_panel = ctk.CTkFrame(self.sidebar, fg_color=t["header"], corner_radius=8)
        self.settings_panel.grid(row=2, column=0, sticky="ew", padx=8, pady=(4, 0))
        self.settings_panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self.settings_panel, text="  Theme",
            font=("Segoe UI", 12, "bold"), text_color=t["accent"]
        ).grid(row=0, column=0, padx=12, pady=(10, 4), sticky="w")

        self.theme_var = ctk.StringVar(value=self.current_theme)
        self.theme_buttons = []
        for i, theme_name in enumerate(THEMES.keys()):
            rb = ctk.CTkRadioButton(
                self.settings_panel, text=theme_name,
                variable=self.theme_var, value=theme_name,
                font=("Segoe UI", 11), text_color=t["text"],
                command=self.apply_theme
            )
            rb.grid(row=i+1, column=0, padx=20, pady=3, sticky="w")
            self.theme_buttons.append(rb)

        ctk.CTkFrame(self.settings_panel, height=10, fg_color="transparent").grid(
            row=len(THEMES)+1, column=0)
        self.settings_panel.grid_remove()

        # Analyse button
        self.browse_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent", height=50)
        self.browse_frame.grid(row=3, column=0, sticky="ew", padx=12, pady=(6, 0))
        self.browse_frame.grid_columnconfigure(0, weight=1)
        self.browse_frame.grid_propagate(False)

        self.analyse_btn = ctk.CTkButton(
            self.browse_frame, text="📄  Analyse File", height=34, corner_radius=10,
            font=("Segoe UI", 11), fg_color=t["input"], hover_color=t["border"],
            border_width=1, border_color=t["border"], text_color=t["text"],
            command=self.browse_file
        )
        self.analyse_btn.grid(row=0, column=0, sticky="ew", pady=8)

        # Input bar
        self.input_frame = ctk.CTkFrame(self.sidebar, fg_color=t["header"], corner_radius=12, height=72)
        self.input_frame.grid(row=4, column=0, sticky="ew", padx=8, pady=8)
        self.input_frame.grid_propagate(False)
        self.input_frame.grid_columnconfigure(0, weight=1)

        self.input_field = ctk.CTkEntry(
            self.input_frame, placeholder_text="Ask me anything...",
            font=("Segoe UI", 12), height=42, corner_radius=21,
            fg_color=t["input"], border_color=t["border"], text_color=t["text"]
        )
        self.input_field.grid(row=0, column=0, padx=(12, 6), pady=15, sticky="ew")
        self.input_field.bind("<Return>", self.send_message)

        self.send_btn = ctk.CTkButton(
            self.input_frame, text="→", width=42, height=42, corner_radius=21,
            font=("Segoe UI", 16, "bold"), fg_color=t["button"],
            hover_color=t["button_hover"], command=self.send_message
        )
        self.send_btn.grid(row=0, column=1, padx=(0, 12), pady=15)

        self.sidebar.grid_remove()
        self.append_message("ai", "Hi! I'm Superpooper. Ask me anything or click Analyse File to summarise a document.")

    def _build_tray(self):
        icon_path = os.path.join(os.path.dirname(sys.executable), "icon.ico")
        tray_image = Image.open(icon_path) if os.path.exists(icon_path) else Image.new("RGB", (64, 64), color="#4c1d95")
        menu = pystray.Menu(
            pystray.MenuItem("Show / Hide", self._tray_toggle, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit Superpooper", self._tray_quit)
        )
        self.tray_icon = pystray.Icon("Superpooper", tray_image, "Superpooper", menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def _tray_toggle(self):
        self.after(0, self.toggle)

    def _tray_quit(self):
        self.tray_icon.stop()
        self.after(0, self.destroy)

    # ── Settings ──────────────────────────────────────────────────
    def toggle_settings(self):
        if self.settings_open:
            self.settings_panel.grid_remove()
            self.settings_open = False
        else:
            self.settings_panel.grid()
            self.settings_open = True

    def apply_theme(self):
        self.current_theme = self.theme_var.get()
        t = self._t()
        ctk.set_appearance_mode(t["appearance"])
        self.configure(fg_color=t["bg"])
        self.tab_col.configure(fg_color=t["bg"])
        self.pill.configure(fg_color=t["header"], border_color=t["border"])
        self.sep.configure(fg_color=t["border"])
        self.arrow_label.configure(text_color=t["accent"])
        self.sidebar.configure(fg_color=t["bg"], border_color=t["border"])
        self.header.configure(fg_color=t["header"])
        self.header_label.configure(text_color=t["accent"])
        self.settings_btn.configure(text_color=t["accent"], border_color=t["border"], hover_color=t["input"])
        self.mini_btn.configure(text_color=t["accent"], border_color=t["border"], hover_color=t["input"])
        self.clear_btn.configure(border_color=t["border"], hover_color=t["input"])
        self.chat_box.configure(fg_color=t["bg"], text_color=t["text"], scrollbar_button_color=t["border"])
        self.settings_panel.configure(fg_color=t["header"])
        self.analyse_btn.configure(fg_color=t["input"], hover_color=t["border"], border_color=t["border"], text_color=t["text"])
        self.input_frame.configure(fg_color=t["header"])
        self.input_field.configure(fg_color=t["input"], border_color=t["border"], text_color=t["text"])
        self.send_btn.configure(fg_color=t["button"], hover_color=t["button_hover"])
        for rb in self.theme_buttons:
            rb.configure(text_color=t["text"])

    # ── Minimise to square ────────────────────────────────────────
    def minimise_to_square(self):
        """Shrink everything down to a small square in the bottom left."""
        if self.animating:
            return
        self.is_mini = True
        self.is_open = False
        self.sidebar.grid_remove()
        t = self._t()
        square_y = self.screen_h - MINI_SIZE - 48  # above taskbar

        # Replace pill content with expand arrow
        self.arrow_label.configure(text="⬡", font=("Segoe UI", 22, "bold"))

        # Animate shrink
        self.animating = True
        start_w = TAB_WIDTH
        start_h = self.screen_h

        def step(i):
            progress = i / ANIMATION_STEPS
            w = int(start_w + (MINI_SIZE - start_w) * progress)
            h = int(start_h + (MINI_SIZE - start_h) * progress)
            y = int(0 + (square_y) * progress)
            self.geometry(f"{w}x{h}+0+{y}")
            if i >= ANIMATION_STEPS:
                self.geometry(f"{MINI_SIZE}x{MINI_SIZE}+0+{square_y}")
                self.animating = False
                # Restyle pill to fill the square
                self.pill.configure(width=MINI_SIZE - 4, height=MINI_SIZE - 4, corner_radius=12)
                self.arrow_label.configure(width=MINI_SIZE - 4, height=MINI_SIZE - 4)
                self.pill.place(relx=0.5, rely=0.5, anchor="center")
                return
            self.after(ANIMATION_DELAY, lambda: step(i + 1))

        step(0)

    def restore_from_square(self):
        """Expand back to full sidebar pill."""
        if self.animating:
            return
        self.is_mini = False
        self.animating = True
        square_y = self.screen_h - MINI_SIZE - 48

        # Restore pill size
        self.pill.configure(width=TAB_WIDTH - 10, height=TAB_HEIGHT, corner_radius=22)
        self.arrow_label.configure(
            text="›", font=("Segoe UI", 36, "bold"),
            width=TAB_WIDTH - 10, height=TAB_HEIGHT
        )
        self.pill.place(relx=0.5, rely=0.5, anchor="center")

        def step(i):
            progress = i / ANIMATION_STEPS
            w = int(MINI_SIZE + (TAB_WIDTH - MINI_SIZE) * progress)
            h = int(MINI_SIZE + (self.screen_h - MINI_SIZE) * progress)
            y = int(square_y + (0 - square_y) * progress)
            self.geometry(f"{w}x{h}+0+{y}")
            if i >= ANIMATION_STEPS:
                self.geometry(f"{TAB_WIDTH}x{self.screen_h}+0+0")
                self.animating = False
                return
            self.after(ANIMATION_DELAY, lambda: step(i + 1))

        step(0)

    # ── Chat ──────────────────────────────────────────────────────
    def append_message(self, role, text):
        self.chat_box.configure(state="normal")
        if role == "user":
            self.chat_box.insert("end", "\n  You\n")
            self.chat_box.insert("end", f"  {text}\n")
        else:
            self.chat_box.insert("end", "\n  Superpooper\n")
            self.chat_box.insert("end", f"  {text}\n")
        self.chat_box.configure(state="disabled")
        self.chat_box.see("end")

    def append_chunk(self, chunk):
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", chunk)
        self.chat_box.configure(state="disabled")
        self.chat_box.see("end")

    def start_ai_message(self):
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", "\n  Superpooper\n  ")
        self.chat_box.configure(state="disabled")

    def end_ai_message(self):
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", "\n")
        self.chat_box.configure(state="disabled")
        self.set_loading(False)

    def set_loading(self, loading):
        state = "disabled" if loading else "normal"
        self.send_btn.configure(state=state, text="…" if loading else "→")
        self.input_field.configure(state=state)

    def send_message(self, event=None):
        user_input = self.input_field.get().strip()
        if not user_input:
            return
        self.input_field.delete(0, "end")
        self.append_message("user", user_input)
        self.set_loading(True)
        self.after(0, self.start_ai_message)
        def run():
            stream_text(
                user_input,
                on_chunk=lambda c: self.after(0, lambda c=c: self.append_chunk(c)),
                on_done=lambda: self.after(0, self.end_ai_message)
            )
        threading.Thread(target=run, daemon=True).start()

    def browse_file(self):
        path = filedialog.askopenfilename(
            title="Select a file",
            filetypes=[("Supported files", "*.pdf *.txt *.md *.csv *.py *.js *.html *.json")]
        )
        if not path:
            return
        self.append_message("user", f"[File: {os.path.basename(path)}]")
        self.set_loading(True)
        self.after(0, self.start_ai_message)
        def run():
            stream_file(
                path,
                on_chunk=lambda c: self.after(0, lambda c=c: self.append_chunk(c)),
                on_done=lambda: self.after(0, self.end_ai_message)
            )
        threading.Thread(target=run, daemon=True).start()

    def clear_chat(self):
        conversation_history.clear()
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", "end")
        self.chat_box.configure(state="disabled")
        self.append_message("ai", "Chat cleared! Ask me anything.")

    # ── Toggle ────────────────────────────────────────────────────
    def toggle(self):
        if self.animating:
            return
        if self.is_mini:
            self.restore_from_square()
            return
        if self.is_open:
            self.close_sidebar()
        else:
            self.open_sidebar()

    def open_sidebar(self):
        self.animating = True
        self.sidebar.grid()
        self.arrow_label.configure(text="‹")

        def step(i):
            w = int(TAB_WIDTH + (SIDEBAR_WIDTH * i / ANIMATION_STEPS))
            self.geometry(f"{w}x{self.screen_h}+0+0")
            if i >= ANIMATION_STEPS:
                self.geometry(f"{TAB_WIDTH + SIDEBAR_WIDTH}x{self.screen_h}+0+0")
                self.is_open = True
                self.animating = False
                self.lift()
                self.input_field.focus()
                return
            self.after(ANIMATION_DELAY, lambda: step(i + 1))

        step(0)

    def close_sidebar(self):
        self.animating = True
        self.arrow_label.configure(text="›")

        def step(i):
            w = int((TAB_WIDTH + SIDEBAR_WIDTH) - (SIDEBAR_WIDTH * i / ANIMATION_STEPS))
            self.geometry(f"{w}x{self.screen_h}+0+0")
            if i >= ANIMATION_STEPS:
                self.geometry(f"{TAB_WIDTH}x{self.screen_h}+0+0")
                self.sidebar.grid_remove()
                self.is_open = False
                self.animating = False
                return
            self.after(ANIMATION_DELAY, lambda: step(i + 1))

        step(0)


if __name__ == "__main__":
    app = SuperpooperApp()
    app.mainloop()