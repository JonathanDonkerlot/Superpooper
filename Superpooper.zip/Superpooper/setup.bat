@echo off
echo.
echo  ================================
echo   Superpooper Setup
echo   by Superpooper Labs
echo  ================================
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] Please run as Administrator.
    echo      Right click setup.bat and select "Run as administrator"
    pause
    exit /b
)

set "INSTALLER_DIR=%~dp0"
cd /d "%INSTALLER_DIR%"

echo  [1/6] Checking for Python...
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] Python not found.
    echo      Please install Python from https://python.org/downloads
    echo      Make sure to check "Add Python to PATH" during install.
    pause
    exit /b
)
echo       Found.

echo  [2/6] Checking for Ollama...
where ollama >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] Ollama not found.
    echo      Please install Ollama from https://ollama.com/download
    echo      Then run this setup again.
    pause
    exit /b
)
echo       Found.

echo  [3/6] Pulling AI model (this may take a few minutes)...
ollama pull phi4-mini
echo       Done.

echo  [4/6] Installing Python dependencies...
python -m pip install pyinstaller customtkinter ollama pymupdf pystray pillow >nul 2>&1
echo       Done.

echo  [5/6] Building Superpooper.exe...
python -m PyInstaller --onefile --windowed --icon="%INSTALLER_DIR%icon.ico" --name "Superpooper" --collect-all customtkinter --collect-all fitz --hidden-import pystray --version-file "%INSTALLER_DIR%version.txt" "%INSTALLER_DIR%Superpooper.py"

if not exist "%INSTALLER_DIR%dist\Superpooper.exe" (
    echo.
    echo  [!] Build failed. Check errors above.
    pause
    exit /b
)

echo  [6/6] Installing...
if not exist "C:\Program Files\Superpooper" mkdir "C:\Program Files\Superpooper"
copy /Y "%INSTALLER_DIR%dist\Superpooper.exe" "C:\Program Files\Superpooper\Superpooper.exe"
copy /Y "%INSTALLER_DIR%icon.ico" "C:\Program Files\Superpooper\icon.ico"
copy /Y "%INSTALLER_DIR%version.txt" "C:\Program Files\Superpooper\version.txt"

if not exist "C:\Program Files\Superpooper\Superpooper.exe" (
    echo  [!] Copy failed.
    pause
    exit /b
)

powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\Superpooper.lnk'); $s.TargetPath='C:\Program Files\Superpooper\Superpooper.exe'; $s.IconLocation='C:\Program Files\Superpooper\icon.ico'; $s.Description='Superpooper - Local AI Assistant'; $s.Save()"
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Superpooper.lnk'); $s.TargetPath='C:\Program Files\Superpooper\Superpooper.exe'; $s.IconLocation='C:\Program Files\Superpooper\icon.ico'; $s.Description='Superpooper - Local AI Assistant'; $s.Save()"

echo  Cleaning up...
rmdir /S /Q "%INSTALLER_DIR%build" >nul 2>&1
rmdir /S /Q "%INSTALLER_DIR%dist" >nul 2>&1
del /Q "%INSTALLER_DIR%*.spec" >nul 2>&1

echo.
echo  ================================
echo   Superpooper installed successfully!
echo   Launching now...
echo  ================================
echo.

start "" "C:\Program Files\Superpooper\Superpooper.exe"
exit